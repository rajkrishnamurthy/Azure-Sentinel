import logging

import azure.functions as func
import msal
import os

from msrest.authentication import BasicTokenAuthentication
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.core.pipeline.policies import BearerTokenCredentialPolicy
from azure.core.pipeline import PipelineRequest, PipelineContext
from azure.core.pipeline.transport import HttpRequest

from azure.loganalytics import LogAnalyticsDataClient
from azure.loganalytics.models import QueryBody

import numpy as np
import uuid
import json
import random
import string
import timeit
import aiohttp
from pandas import json_normalize
import requests
import asyncio
import sys

import base64
import gzip


PARAMS = {}

class CredentialWrapper(BasicTokenAuthentication):
    def __init__(self, credential=None, resource_id="https://westus2.api.loganalytics.io/.default", **kwargs):
        """Wrap any azure-identity credential to work with SDK that needs azure.common.credentials/msrestazure.
        Default resource is ARM (syntax of endpoint v2)
        :param credential: Any azure-identity credential (DefaultAzureCredential by default)
        :param str resource_id: The scope to use to get the token (default ARM)
        """
        super(CredentialWrapper, self).__init__(None)
        if credential is None:
            credential = DefaultAzureCredential()
        self._policy = BearerTokenCredentialPolicy(
            credential, resource_id, **kwargs)

    def _make_request(self):
        return PipelineRequest(
            HttpRequest(
                "CredentialWrapper",
                "https://fakeurl"
            ),
            PipelineContext(None)
        )

    def set_token(self):
        """Ask the azure-core BearerTokenCredentialPolicy policy to get a token.
        Using the policy gives us for free the caching system of azure-core.
        We could make this code simpler by using private method, but by definition
        I can't assure they will be there forever, so mocking a fake call to the policy
        to extract the token, using 100% public API."""
        request = self._make_request()
        self._policy.on_request(request)
        # Read Authorization, and get the second part after Bearer
        token = request.http_request.headers["Authorization"].split(" ", 1)[1]
        self.token = {"access_token": token}

    def signed_session(self, session=None):
        self.set_token()
        return super(CredentialWrapper, self).signed_session(session)


def get_honey_token_def(dfItems, keywords):

    attributes = ''

    items_list = list(dfItems['id'])
    if len(items_list) < 3:
        honey_token_name = np.random.choice(keywords) + np.random.choice(['-', '']) + np.random.choice(
            [str(uuid.uuid4())] + list(range(10)))

    else:
        selected = np.random.choice(dfItems.shape[0])
        key2replicate = items_list[selected]
        honey_token_name = key2replicate
        for kw in keywords:
            if honey_token_name.find(kw) > -1:
                honey_token_name = honey_token_name.replace(kw, np.random.choice(keywords))
                break

        honey_token_name = honey_token_name.translate(
            honey_token_name.maketrans("1234567890", ''.join(list(np.random.choice(list("1234567890"), 10)))))

        # make sure the name is unique
        while honey_token_name in items_list:
            honey_token_name = honey_token_name + str(np.random.choice(range(10)))

        # add attributes (currently exp only)
        if ('attributes.exp' in dfItems.columns):
            selectedVal = list(dfItems['attributes.exp'])[selected]
            if (~np.isnan(selectedVal)):
                attributes = f""",\"attributes\": {{\"exp\":{selectedVal}}}"""

    if np.random.choice(range(2)) > 0:
        honey_token_name = honey_token_name.capitalize()

    return honey_token_name, attributes


async def add_to_watchlist(SentinelResourceId, kv, honeytokenName, keyOrSecret, armHeaders):
    watchlist_item_id = str(uuid.uuid4())
    (dummy, dummy, subscriptionId, dummy, resourceGroupName, dummy, dummy, dummy,
     workspaceName) = SentinelResourceId.split('/')
    qUrl = f"https://management.azure.com/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.OperationalInsights/workspaces/{workspaceName}/providers/Microsoft.SecurityInsights/watchlists/HoneyTokens/watchlistitems/{watchlist_item_id}?api-version=2021-04-01"
    qBody = f"""{{
                    "properties": {{
                        "itemsKeyValue": {{
                            "ResourceProvider": "Microsoft.KeyVault",
                            "ResourceId": "{kv}",
                            "HoneyToken": "{honeytokenName}",
                            "Properties": "{{\\"Type\\": \\"{keyOrSecret}\\"}}"
                        }}
                    }}
                }}"""
    async with aiohttp.ClientSession() as session:
        async with session.put(qUrl, data=qBody, headers=armHeaders) as response:  # armHeaders
            response_text = await response.text()
    watch_list_item_creation = json.loads(response_text)
    return watch_list_item_creation


async def create_honey_token(kv, key_or_secret, dfKeys, dfSecrets, kvHeaders):
    if key_or_secret == "key":
        dfItems = dfKeys
        dfItems['id'] = dfKeys.kid.str.split('/').apply(lambda l: l[-1])
    else:  # secret
        dfItems = dfSecrets
        dfItems['id'] = dfSecrets.id.str.split('/').apply(lambda l: l[-1])
    honeytoken_name, attributes = get_honey_token_def(dfItems, PARAMS[key_or_secret.upper() + '_KEYWORDS'])

    (dummy, dummy, subscriptionId, dummy, resourceGroupName, dummy, dummy, dummy, kvName) = kv.split('/')
    qUrl = f"https://{kvName}.vault.azure.net/{key_or_secret}s/{honeytoken_name}/create?api-version=7.2"

    if key_or_secret == "key":
        qBody = f"""{{
                "kty": "{np.random.choice(['RSA', 'EC'])}"
                {attributes}
                }}"""
        async with aiohttp.ClientSession() as session:
            async with session.post(qUrl, data=qBody, headers=kvHeaders) as response:
                responseText = await response.text()
    else:  # secret
        qBody = f"""{{
                "value": "{''.join(random.choices(string.ascii_letters + string.digits + '-.~_', k=34))}"
                {attributes}
                }}"""
        async with aiohttp.ClientSession() as session:
            async with session.put(qUrl, data=qBody, headers=kvHeaders) as response:
                responseText = await response.text()

    htCreation = json.loads(responseText)
    return htCreation, honeytoken_name


def generate_honey_token_query(type, kv, df, monitored_by_soc_thresh=0):

    column = None
    if type == "secret":
        column = df.id
    if type == "key":
        column = df.kid
    query = f"""_GetWatchlist('HoneyTokens') 
                            | union (print ResourceProvider="dummy", ResourceId="dummy", HoneyToken="dummy")
                            | where tolower(ResourceProvider) == 'microsoft.keyvault' 
                            | where ResourceId == "{kv}"
                            | where todynamic(Properties).Type == "{type}"
                            | where HoneyToken in ({", ".join(list(column.str.split('/').apply(lambda l: '"' + l[-1] + '"')))})
                            | count
                            | project MonitoredBySoc=Count>{monitored_by_soc_thresh} 
                            """
    return query


async def add_honey_token(kv, LA_client, sentinel_ws, sentinel_resource_id, kv_headers, arm_headers, iterNum=0):
    status = {}
    monitored_by_soc = False

    # get the keys list
    (_, _, subscriptionId, _, resourceGroupName, _, _, _, kvName) = kv.split('/')
    query = f"https://{kvName}.vault.azure.net/keys?api-version=7.2"
    async with aiohttp.ClientSession() as session:
        async with session.get(query, headers=kv_headers) as response:
            response_text = await response.text()
    keys_list = json.loads(response_text)
    if 'error' in keys_list:
        status = keys_list

    # check if a honey-token is already deployed
    if 'error' not in status:
        df_keys = json_normalize(keys_list, 'value')
        monitored_by_soc = False
        if df_keys.shape[0] > 0:
            query = generate_honey_token_query("key", kv, df_keys, iterNum)

            try:
                monitored_by_soc = LA_client.query(sentinel_ws, QueryBody(query=query)).tables[0].rows[0][0]
            except Exception as e:
                status = {'error': {"message": str(e), 'code': "HoneyTokensWatchListQueryFailed"}}

    if ('error' not in status) and (not monitored_by_soc):
        (dummy, dummy, subscriptionId, dummy, resourceGroupName, dummy, dummy, dummy, kvName) = kv.split('/')
        query = f"https://{kvName}.vault.azure.net/secrets?api-version=7.2"
        async with aiohttp.ClientSession() as session:
            async with session.get(query, headers=kv_headers) as response:
                response_text = await response.text()
        secrets_list = json.loads(response_text)
        if 'error' in secrets_list:
            status = secrets_list

        if 'error' not in status:
            df_secrets = json_normalize(secrets_list, 'value')
            monitored_by_soc = False
            if df_secrets.shape[0] > 0:
                query = generate_honey_token_query("secret", kv, df_secrets, 0)

                try:
                    monitored_by_soc = LA_client.query(sentinel_ws, QueryBody(query=query)).tables[0].rows[0][0]
                except Exception as e:
                    status = {'error': {"message": str(e), 'code': "HoneyTokensWatchListQueryFailed"}}

    # if no honeytoken key exists - create one and add it to Sentinel's HoneyTokens watchlist
    watch_list_item_creation = {}
    if ('error' not in status) and (not monitored_by_soc):
        # if no keys or secrets already exist, no need for a HT    
        if df_keys.shape[0] + df_secrets.shape[0] > 0:
            keyOrSecret = np.random.choice(["key"] * df_keys.shape[0] + ["secret"] * df_secrets.shape[0])

            htCreation, honeytokenName = await create_honey_token(kv, keyOrSecret, df_keys, df_secrets, kv_headers)
            if 'error' in htCreation:
                status = htCreation

            # add to the watchlist
            if 'error' not in status:
                watch_list_item_creation = await add_to_watchlist(sentinel_resource_id, kv, honeytokenName, keyOrSecret,
                                                                  arm_headers)
                if 'error' in watch_list_item_creation:
                    status = watch_list_item_creation
        else:
            status = {'error': {"message": "KeyVault has no secrets or keys", 'code': "EmptyKeyVault"}}

    if 'error' not in status:
        return watch_list_item_creation
    return status


async def deploy_HT(kv, sentinel_ws, sentinel_resource_id, LA_client, kv_headers, arm_headers):
    task_start = timeit.default_timer()

    # list keys/secrets for the KV

    prob = 1
    iterNum = 0
    while np.random.rand() < prob:
        resAddHT = await add_honey_token(kv, LA_client, sentinel_ws, sentinel_resource_id, kv_headers, arm_headers,
                                         iterNum)
        iterNum = iterNum + 1
        if 'error' in resAddHT.keys():
            resAddHT["stage"] = "addHoneyToken"
            resAddHT["Time"] = timeit.default_timer() - task_start
            return resAddHT
        prob = prob * PARAMS['ADDITIONAL_HT_PROB']

    return {"Result": "success", "Time": timeit.default_timer() - task_start}


async def parallel_HT_deployment(keyVaults, SentinelWS, SentinelResourceId, LAClient, kvHeaders, armHeaders):
    outJson = []
    tasks = []
    for kv in keyVaults:
        outJson.append({"KeyVaultResoutceId": kv})
        tasks.append(deploy_HT(kv, SentinelWS, SentinelResourceId, LAClient, kvHeaders, armHeaders))

    tasksOutput = await asyncio.gather(*tasks)

    # assign the results to outJson
    j = 0
    for kvInd, kv in enumerate(keyVaults):
        outJson[kvInd]['status'] = tasksOutput[j]
        j = j + 1

    return outJson


def get_customer_specific_conf():
    try:
        global PARAMS
        PARAMS = eval(os.getenv('PARAMS'))

        if (PARAMS['ADDITIONAL_HT_PROB'] >= 1) or (PARAMS['ADDITIONAL_HT_PROB'] < 0):
            raise Exception({
                "message": "Invalid param value: ADDITIONAL_HT_PROB={PARAMS['ADDITIONAL_HT_PROB']}. "
                           "Values should be in the range [0,1)]"})
    except Exception as e:
        return func.HttpResponse(f"Problem reading PARAMS: {e}")


def check_refresh_token_availability(req):
    try:
        cookie = {pair.split('=')[0]: pair.split('=')[1] for pair in
                  req.headers.get('cookie').split(';')}  # get a hash of the cookies
        use_refresh_token = False
        if "refreshToken" not in cookie.keys():
            refresh_token = req.headers.get('x-ms-token-aad-refresh-token')
        else:
            refresh_token = cookie['refreshToken']
            use_refresh_token = True
    except Exception as e:
        raise Exception({"Message": f"problem reading cookies: {e}"})

    return use_refresh_token, refresh_token, cookie


def get_html_results(dfOutput):
    htmlResults = f"""<html>
                <head>
                <style>
                #KeyVaults {{
                font-family: Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                }}

                #KeyVaults td, #customers th {{
                border: 1px solid #ddd;
                padding: 8px;
                }}

                #KeyVaults tr:nth-child(even){{background-color: #f2f2f2;}}

                #KeyVaults tr:hover {{background-color: #ddd;}}

                #KeyVaults th {{
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #0080ff;
                color: white;
                }}
                </style>
                </head>
                <body>
                <h1>HoneyTokens Deployment Results</h1>
                {dfOutput.to_html(index=False, na_rep="", classes='kvTableClass" id = "KeyVaults')}
                </body>
                </html>
                """
    return htmlResults


async def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('t.Python HTTP trigger function processed a request')

    # get the customer-specific conf
    get_customer_specific_conf()

    # check is a refreshToken is available
    use_refresh_token, refresh_token, cookie = check_refresh_token_availability(req)

    # input params
    # key_vaults = req.params.get('keyVaults')
    zipped_kvs = req.params.get('zippedKVs')
    key_vaults = None
    if (zipped_kvs):
        key_vaults = gzip.decompress(base64.b64decode(zipped_kvs)).decode("utf-8")
        logging.info(f'{key_vaults}')

    sentinel_ws = req.params.get('SentinelWS')
    sentinel_resource_id = req.params.get('SentinelResourceId')
    if key_vaults:
        try:
            key_vaults = key_vaults[1:-1].split(",")
            key_vaults = [kv.strip() for kv in key_vaults]
            token = req.headers.get('x-ms-token-aad-id-token')

            client_id = PARAMS['CLIENT_ID']
            tenant = PARAMS['TENANT']
            secret = os.getenv('HTDeployFuncAppSecret')

            # acquire permissions:
            # to Sentinel and app-secret through a managed identity
            # to the key-vault and ARM through impersonation 
            client_app = msal.ConfidentialClientApplication(
                client_id,
                authority=f"https://login.microsoftonline.com/{tenant}",
                client_credential=secret,
                azure_region=None)

            if use_refresh_token:
                aad_response = client_app.acquire_token_by_refresh_token(refresh_token,
                                                                         ["https://vault.azure.net/user_impersonation"])
            else:
                aad_response = client_app.acquire_token_on_behalf_of(token,
                                                                     ["https://vault.azure.net/user_impersonation"],
                                                                     claims_challenge=None)  #
            if 'error' in aad_response:
                raise Exception(aad_response)
            kv_headers = {'Content-type': 'application/json', 'Accept': 'text/plain',
                          "Authorization": f"Bearer {aad_response['access_token']}"}

            # Sentinel credentials
            creds = CredentialWrapper()
            LA_client = LogAnalyticsDataClient(creds)

            creds2 = DefaultAzureCredential()
            managed_identity_token = creds2.get_token('https://management.azure.com/')
            arm_headers = {'Content-type': 'application/json', 'Accept': 'text/plain',
                           "Authorization": f"Bearer {managed_identity_token.token}"}

            # list the KVs for all subscriptions & deploy HTs where missing
            out_json = await parallel_HT_deployment(key_vaults, sentinel_ws, sentinel_resource_id, LA_client,
                                                    kv_headers,
                                                    arm_headers)

            # create the output HTML
            df_output = json_normalize(out_json)
            for col in ['KeyVaultResoutceId', "status.Result", "status.error.code", 'status.stage',
                        'status.error.innererror.code', 'status.error.message']:
                if col not in df_output.columns:
                    df_output[col] = np.nan
            df_output.loc[~df_output["status.Result"].isnull(), "status.Result"] = df_output.loc[
                                                                                   ~df_output["status.Result"].isnull(),
                                                                                   :].apply(
                lambda row: "\u2705 " + row["status.Result"], axis=1)
            df_output.loc[df_output["status.Result"].isnull(), "status.Result"] = df_output.loc[
                                                                                  df_output["status.Result"].isnull(),
                                                                                  :].apply(
                lambda row: "\u274C " + row["status.error.code"], axis=1)
            df_output = df_output.loc[:,
                        ['KeyVaultResoutceId', "status.Result", 'status.stage', 'status.error.innererror.code',
                         'status.error.message']]
            df_output.columns = ['KeyVaultResoutceId', "Result", 'StageFailed', 'ErrorCode', 'ErrorMessage']

            html_results = get_html_results(df_output)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            return func.HttpResponse(f"{e}, {exc_type}, {fname}, {exc_tb.tb_lineno}")

        return func.HttpResponse(f"{html_results}",
                                 headers={'Content-type': 'text/html; charset=UTF-8',
                                          "Set-Cookie": f"refreshToken={refresh_token}; Secure; HttpOnly"},
                                 status_code=200)
    elif req.params.get('DEBUG'):
        return func.HttpResponse(f"{cookie}, {req.headers.__dict__}",
                                 headers={'Content-type': 'text/html; charset=UTF-8'},
                                 status_code=200)
    else:
        html_results = """
        <html>
        <body>
        <H2>Please run this function only from the HoneyTokens management workbook</H2>
        </body>
        </html>"""
        return func.HttpResponse(f"{html_results}",
                                 headers={'Content-type': 'text/html; charset=UTF-8'},
                                 status_code=200)
